# Telegram Video Bot
This bot processes uploaded videos using FFmpeg filters and sends the output back.